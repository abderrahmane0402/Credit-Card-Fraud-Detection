# Fraud Detection Streaming: Phase 2

This package creates the local infrastructure for the streaming fraud-detection project:

- Apache Kafka in KRaft mode
- Three Kafka topics
- Kafka UI
- PostgreSQL with an idempotent prediction schema
- Local verification scripts

## Prerequisites

- Docker Desktop with Docker Compose
- Python 3.10 or newer
- The model artifacts exported from Kaggle

## Setup

### 1. Extract the project

Open a terminal inside this directory.

### 2. Create the environment file

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Command Prompt:

```bat
copy .env.example .env
```

Linux or macOS:

```bash
cp .env.example .env
```

The credentials are for local development only.

### 3. Add Kaggle artifacts

Extract all six files from `fraud-model-artifacts.zip` into `models/`.

### 4. Start infrastructure

```bash
docker compose up -d
```

Inspect status:

```bash
docker compose ps
```

Inspect startup logs if needed:

```bash
docker compose logs kafka postgres topic-init
```

### 5. Open Kafka UI

Open `http://localhost:8080`. The expected topics are:

- `transactions.raw`
- `transactions.scored`
- `transactions.dead-letter`

### 6. Verify PostgreSQL and the model

Create a virtual environment and install local verification dependencies.

Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-local.txt
python scripts/check_infrastructure.py
python scripts/verify_model.py
```

Linux or macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-local.txt
python scripts/check_infrastructure.py
python scripts/verify_model.py
```

Expected messages:

```text
POSTGRES VERIFICATION PASSED
MODEL VERIFICATION PASSED
```

## Useful commands

Stop containers without deleting data:

```bash
docker compose stop
```

Restart:

```bash
docker compose start
```

Delete containers and development volumes, then initialize from scratch:

```bash
docker compose down -v
```

Warning: the final command deletes local Kafka and PostgreSQL data.

## Next phase

The next phase adds a validated CSV replay producer that publishes JSON events to `transactions.raw`.
