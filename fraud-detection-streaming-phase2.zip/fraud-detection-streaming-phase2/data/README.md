# Local data

Place `creditcard.csv` in this directory for the historical transaction replay producer.
Do not commit the dataset to Git. Preserve the original column names: `Time`, `V1` through `V28`, `Amount`, and `Class`.
